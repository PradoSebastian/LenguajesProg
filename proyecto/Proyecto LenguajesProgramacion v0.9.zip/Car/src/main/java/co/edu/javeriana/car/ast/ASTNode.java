package co.edu.javeriana.car.ast;

public interface ASTNode {
	public Object execute(Context context);
}
