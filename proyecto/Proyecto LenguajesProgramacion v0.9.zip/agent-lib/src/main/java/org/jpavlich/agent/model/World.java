package org.jpavlich.agent.model;

public interface World {

	int getHeight();

	int getWidth();

}
