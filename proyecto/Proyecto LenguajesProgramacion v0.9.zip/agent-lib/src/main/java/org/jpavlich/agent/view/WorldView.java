package org.jpavlich.agent.view;

import processing.core.PApplet;

public class WorldView extends Layer {



	@Override
	public void init(PApplet applet) {
		
	}

	@Override
	public void draw() {
		
	}


}
